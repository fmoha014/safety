"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getResourcesByCategory } from "@/lib/data/resources";
import { Phone, AlertTriangle, MapPin, Copy, Check } from "lucide-react";
import { toast } from "sonner";

export default function EmergencyPage() {
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);
  const hotlines = getResourcesByCategory("hotline");

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        setCopiedNumber(text);
        toast.success("Phone number copied to clipboard");
        setTimeout(() => setCopiedNumber(null), 3000);
      })
      .catch((error) => {
        console.error("Error copying to clipboard:", error);
        toast.error("Failed to copy number");
      });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-red-600">Emergency Help</h1>
        <p className="text-gray-600 mt-2">
          Quick access to emergency resources and hotlines for immediate assistance.
        </p>
      </div>

      {/* Emergency Call Box */}
      <Card className="bg-red-50 border-red-200 mb-8">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <AlertTriangle className="text-red-600" size={24} />
            <CardTitle className="text-red-700">In Immediate Danger</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4">
            <div className="flex-1 bg-white p-4 rounded-lg border border-red-100">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg">Call 999</h3>
                  <p className="text-sm text-gray-600">Emergency services</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1"
                  onClick={() => copyToClipboard("999")}
                >
                  {copiedNumber === "999" ? (
                    <Check size={16} className="text-green-500" />
                  ) : (
                    <Copy size={16} />
                  )}
                  <span>Copy</span>
                </Button>
              </div>
            </div>

            <div className="flex-1 bg-white p-4 rounded-lg border border-red-100">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-lg">Silent Help: 55</h3>
                  <p className="text-sm text-gray-600">Press 55 when prompted if you can't speak</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 gap-1"
                  onClick={() => copyToClipboard("55")}
                >
                  {copiedNumber === "55" ? (
                    <Check size={16} className="text-green-500" />
                  ) : (
                    <Copy size={16} />
                  )}
                  <span>Copy</span>
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* National Hotlines */}
      <h2 className="text-xl font-bold mb-4">National Support Hotlines</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {hotlines.map((hotline) => (
          <Card key={hotline.id} className="h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-violet-700 text-lg">{hotline.name}</CardTitle>
              {hotline.hours && (
                <CardDescription>{hotline.hours}</CardDescription>
              )}
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">{hotline.description}</p>
              {hotline.phoneNumber && (
                <div className="flex items-center justify-between bg-violet-50 p-3 rounded-md">
                  <div className="flex items-center gap-2">
                    <Phone className="text-violet-600" size={18} />
                    <span className="font-medium">{hotline.phoneNumber}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8"
                    onClick={() => copyToClipboard(hotline.phoneNumber || "")}
                  >
                    {copiedNumber === hotline.phoneNumber ? (
                      <Check size={16} className="text-green-500" />
                    ) : (
                      <Copy size={16} />
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
            {hotline.website && (
              <CardFooter>
                <Button asChild variant="outline" className="w-full">
                  <a href={hotline.website} target="_blank" rel="noopener noreferrer">
                    Visit Website
                  </a>
                </Button>
              </CardFooter>
            )}
          </Card>
        ))}
      </div>

      {/* Safety Information */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Safety Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3 list-disc pl-5">
            <li>
              <strong>Trust your instincts.</strong> If you feel unsafe, seek help immediately.
            </li>
            <li>
              <strong>Create a code word</strong> with friends or family that signals you need help.
            </li>
            <li>
              <strong>Prepare an emergency bag</strong> with essential documents, medication, and personal items.
            </li>
            <li>
              <strong>Know your escape routes</strong> and safe places you can go in an emergency.
            </li>
            <li>
              <strong>Use private browsing</strong> when seeking help online, or clear your browsing history afterward.
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Local Police Stations */}
      <Card>
        <CardHeader>
          <CardTitle>Find Local Police Stations</CardTitle>
          <CardDescription>
            In a non-emergency situation, you can visit your local police station.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 text-violet-700 mb-4">
            <MapPin size={18} />
            <span>Find your nearest police station:</span>
          </div>
          <Button asChild className="w-full md:w-auto">
            <a
              href="https://www.police.uk/pu/your-area/find-your-neighbourhood/"
              target="_blank"
              rel="noopener noreferrer"
            >
              Search Police UK
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
