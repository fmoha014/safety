"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { generateReportPDF, IncidentReport, saveEvidenceFile } from "@/lib/utils/report-helpers";
import { v4 as uuidv4 } from "uuid";
import { toast } from "sonner";
import { FilePenLine, FileDown, Plus, X } from "lucide-react";

export default function ReportPage() {
  const [step, setStep] = useState<number>(1);
  const [uploadedFiles, setUploadedFiles] = useState<{ name: string; url: string }[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [reportGenerated, setReportGenerated] = useState<boolean>(false);

  const { register, handleSubmit, watch, formState: { errors }, setValue, reset } = useForm<IncidentReport>({
    defaultValues: {
      id: uuidv4(),
      createdAt: new Date(),
      reportingPerson: {
        name: "",
        contactInfo: "",
      },
      incidentDetails: {
        date: "",
        time: "",
        location: "",
        description: "",
      },
      witnessDetails: {
        witnesses: false,
      },
      evidenceDetails: {
        hasEvidence: false,
      },
      optionalContent: {
        policeReported: false,
        medicalAttention: false,
      },
    }
  });

  const hasWitnesses = watch("witnessDetails.witnesses", false);
  const hasEvidence = watch("evidenceDetails.hasEvidence", false);
  const policeReported = watch("optionalContent.policeReported", false);
  const medicalAttention = watch("optionalContent.medicalAttention", false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;

    try {
      const file = e.target.files[0];
      const url = await saveEvidenceFile(file);

      const newFiles = [...uploadedFiles, { name: file.name, url }];
      setUploadedFiles(newFiles);

      // Update the form value
      setValue("evidenceDetails.fileNames", newFiles.map(f => f.name));

      toast.success(`File "${file.name}" uploaded`);
      e.target.value = ""; // Reset the input
    } catch (error) {
      toast.error("Error uploading file");
      console.error(error);
    }
  };

  const removeFile = (index: number) => {
    const newFiles = [...uploadedFiles];
    newFiles.splice(index, 1);
    setUploadedFiles(newFiles);

    // Update the form value
    setValue("evidenceDetails.fileNames", newFiles.map(f => f.name));

    toast.info("File removed");
  };

  const onSubmit = async (data: IncidentReport) => {
    setIsSubmitting(true);

    try {
      // Generate PDF from the form data
      generateReportPDF(data);

      setReportGenerated(true);
      toast.success("Incident report generated successfully");

      // Reset form after a successful submission
      setStep(1);
      setUploadedFiles([]);
      reset();

    } catch (error) {
      toast.error("Error generating report");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Function to handle downloading a new report
  const handleDownloadAgain = () => {
    // Create a new report with current form data
    const formData = watch();
    const newReport: IncidentReport = {
      id: uuidv4(),
      createdAt: new Date(),
      reportingPerson: formData.reportingPerson || { name: "", contactInfo: "" },
      incidentDetails: formData.incidentDetails || { date: "", time: "", location: "", description: "" },
      witnessDetails: formData.witnessDetails,
      perpetratorDetails: formData.perpetratorDetails,
      evidenceDetails: formData.evidenceDetails,
      impactStatement: formData.impactStatement,
      assistanceNeeded: formData.assistanceNeeded,
      safetyMeasures: formData.safetyMeasures,
      optionalContent: formData.optionalContent
    };

    // Generate and download the PDF
    generateReportPDF(newReport);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Incident Report</h1>
        <p className="text-gray-600 mt-2">
          Document incidents with detailed reports that can be downloaded for your records or shared with authorities.
        </p>
      </div>

      {/* Safety Exit Reminder */}
      <div className="bg-yellow-100 p-4 rounded-md mb-6">
        <p className="text-yellow-800">
          <strong>Safety Reminder:</strong> You can quickly exit this page by pressing ESC or clicking the "Quick Exit" button in the footer.
        </p>
      </div>

      {/* Step Navigation */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <button
              key={i}
              onClick={() => setStep(i + 1)}
              className={`h-9 w-9 rounded-full flex items-center justify-center ${
                step === i + 1
                  ? "bg-violet-600 text-white"
                  : step > i + 1
                  ? "bg-violet-200 text-violet-600"
                  : "bg-gray-200 text-gray-500"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
        <div className="text-sm text-gray-500">
          Step {step} of 4
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)}>
        <Card className="mb-6">
          {step === 1 && (
            <>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>
                  This information helps identify your report but can be anonymized if preferred.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reportingPerson.name">Your Name (or pseudonym)</Label>
                  <Input
                    id="reportingPerson.name"
                    placeholder="Enter your name or use a pseudonym"
                    {...register("reportingPerson.name", { required: "Name is required" })}
                  />
                  {errors.reportingPerson?.name && (
                    <p className="text-sm text-red-500">{errors.reportingPerson.name.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="reportingPerson.contactInfo">Contact Information (optional)</Label>
                  <Input
                    id="reportingPerson.contactInfo"
                    placeholder="Phone number or email address"
                    {...register("reportingPerson.contactInfo")}
                  />
                  <p className="text-xs text-gray-500">
                    This information is not required and will only be included in your downloaded report.
                  </p>
                </div>
              </CardContent>
            </>
          )}

          {step === 2 && (
            <>
              <CardHeader>
                <CardTitle>Incident Details</CardTitle>
                <CardDescription>
                  Please provide details about when and where the incident occurred.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="incidentDetails.date">Date of Incident</Label>
                    <Input
                      id="incidentDetails.date"
                      type="date"
                      {...register("incidentDetails.date", { required: "Date is required" })}
                    />
                    {errors.incidentDetails?.date && (
                      <p className="text-sm text-red-500">{errors.incidentDetails.date.message}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="incidentDetails.time">Time of Incident (approximate)</Label>
                    <Input
                      id="incidentDetails.time"
                      type="time"
                      {...register("incidentDetails.time")}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="incidentDetails.location">Location</Label>
                  <Input
                    id="incidentDetails.location"
                    placeholder="Where did the incident take place?"
                    {...register("incidentDetails.location", { required: "Location is required" })}
                  />
                  {errors.incidentDetails?.location && (
                    <p className="text-sm text-red-500">{errors.incidentDetails.location.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="incidentDetails.description">Description of the Incident</Label>
                  <Textarea
                    id="incidentDetails.description"
                    placeholder="Please describe what happened"
                    className="min-h-[150px]"
                    {...register("incidentDetails.description", { required: "Description is required" })}
                  />
                  {errors.incidentDetails?.description && (
                    <p className="text-sm text-red-500">{errors.incidentDetails.description.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="perpetratorDetails.name">Name of Person Responsible (if known)</Label>
                  <Input
                    id="perpetratorDetails.name"
                    placeholder="Name of the person involved"
                    {...register("perpetratorDetails.name")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="perpetratorDetails.relationship">Relationship to You</Label>
                  <Input
                    id="perpetratorDetails.relationship"
                    placeholder="e.g., Partner, Ex-partner, Family member, Colleague"
                    {...register("perpetratorDetails.relationship")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="perpetratorDetails.description">Description of Person Responsible (optional)</Label>
                  <Textarea
                    id="perpetratorDetails.description"
                    placeholder="Physical description or other identifying details"
                    {...register("perpetratorDetails.description")}
                  />
                </div>
              </CardContent>
            </>
          )}

          {step === 3 && (
            <>
              <CardHeader>
                <CardTitle>Witnesses and Evidence</CardTitle>
                <CardDescription>
                  Information about witnesses or evidence related to the incident.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="witnessDetails.witnesses"
                      className="rounded border-gray-300"
                      {...register("witnessDetails.witnesses")}
                    />
                    <Label htmlFor="witnessDetails.witnesses">Were there any witnesses to the incident?</Label>
                  </div>

                  {hasWitnesses && (
                    <div className="space-y-4 pl-6">
                      <div className="space-y-2">
                        <Label htmlFor="witnessDetails.names">Witness Names (if known)</Label>
                        <Input
                          id="witnessDetails.names"
                          placeholder="Names of witnesses"
                          {...register("witnessDetails.names")}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="witnessDetails.contactInfo">Witness Contact Information (if available)</Label>
                        <Input
                          id="witnessDetails.contactInfo"
                          placeholder="Phone numbers or email addresses"
                          {...register("witnessDetails.contactInfo")}
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="evidenceDetails.hasEvidence"
                      className="rounded border-gray-300"
                      {...register("evidenceDetails.hasEvidence")}
                    />
                    <Label htmlFor="evidenceDetails.hasEvidence">Do you have evidence related to the incident?</Label>
                  </div>

                  {hasEvidence && (
                    <div className="space-y-4 pl-6">
                      <div className="space-y-2">
                        <Label htmlFor="evidenceDetails.descriptions">Description of Evidence</Label>
                        <Textarea
                          id="evidenceDetails.descriptions"
                          placeholder="Describe the evidence you have (e.g., photos, text messages, medical records)"
                          {...register("evidenceDetails.descriptions")}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Upload Evidence Files</Label>
                        <div className="mt-1">
                          <label className="flex items-center justify-center w-full h-12 px-4 transition bg-white border-2 border-gray-300 border-dashed rounded-md appearance-none cursor-pointer hover:border-violet-400 focus:outline-none">
                            <span className="flex items-center space-x-2">
                              <Plus size={18} className="text-gray-400" />
                              <span className="text-sm text-gray-600">Add file</span>
                            </span>
                            <input
                              type="file"
                              className="hidden"
                              onChange={handleFileUpload}
                              accept="image/*,application/pdf,text/plain,.doc,.docx"
                            />
                          </label>
                        </div>

                        {uploadedFiles.length > 0 && (
                          <div className="mt-4 space-y-2">
                            <Label>Uploaded Files</Label>
                            <div className="space-y-2">
                              {uploadedFiles.map((file, index) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
                                >
                                  <span className="text-sm truncate max-w-[80%]">{file.name}</span>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removeFile(index)}
                                  >
                                    <X size={16} className="text-gray-500" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </>
          )}

          {step === 4 && (
            <>
              <CardHeader>
                <CardTitle>Additional Information</CardTitle>
                <CardDescription>
                  Add any other relevant details to complete your report.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="impactStatement">Impact Statement</Label>
                  <Textarea
                    id="impactStatement"
                    placeholder="How has this incident affected you physically, emotionally, financially, etc.?"
                    className="min-h-[100px]"
                    {...register("impactStatement")}
                  />
                  <p className="text-xs text-gray-500">
                    This can help establish the seriousness of the incident.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="assistanceNeeded">Assistance Needed</Label>
                  <Textarea
                    id="assistanceNeeded"
                    placeholder="What kind of help or support do you need?"
                    {...register("assistanceNeeded")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="safetyMeasures">Safety Measures in Place</Label>
                  <Textarea
                    id="safetyMeasures"
                    placeholder="What steps have you taken for your safety?"
                    {...register("safetyMeasures")}
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="optionalContent.policeReported"
                      className="rounded border-gray-300"
                      {...register("optionalContent.policeReported")}
                    />
                    <Label htmlFor="optionalContent.policeReported">Has this incident been reported to the police?</Label>
                  </div>

                  {policeReported && (
                    <div className="space-y-2 pl-6">
                      <Label htmlFor="optionalContent.policeReportNumber">Police Report Number (if available)</Label>
                      <Input
                        id="optionalContent.policeReportNumber"
                        placeholder="Report number or reference"
                        {...register("optionalContent.policeReportNumber")}
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="optionalContent.medicalAttention"
                      className="rounded border-gray-300"
                      {...register("optionalContent.medicalAttention")}
                    />
                    <Label htmlFor="optionalContent.medicalAttention">Did you receive medical attention?</Label>
                  </div>

                  {medicalAttention && (
                    <div className="space-y-2 pl-6">
                      <Label htmlFor="optionalContent.medicalFacility">Medical Facility/Provider</Label>
                      <Input
                        id="optionalContent.medicalFacility"
                        placeholder="Name of hospital, clinic, or doctor"
                        {...register("optionalContent.medicalFacility")}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </>
          )}

          <CardFooter className="flex justify-between">
            {step > 1 && (
              <Button type="button" variant="outline" onClick={() => setStep(step - 1)}>
                Previous
              </Button>
            )}
            {step < 4 ? (
              <Button type="button" onClick={() => setStep(step + 1)} className="ml-auto">
                Next
              </Button>
            ) : (
              <Button type="submit" disabled={isSubmitting} className="ml-auto">
                {isSubmitting ? "Generating..." : "Generate Report"}
              </Button>
            )}
          </CardFooter>
        </Card>
      </form>

      {reportGenerated && (
        <Card className="bg-violet-50 border-violet-200 mb-10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-violet-700">
              <FilePenLine size={20} />
              Report Generated Successfully
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p>
              Your incident report has been generated and downloaded to your device. You can:
            </p>
            <ul className="list-disc list-inside mt-2 space-y-1">
              <li>Save this report for your records</li>
              <li>Share it with support services</li>
              <li>Use it as documentation when working with authorities</li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button
              type="button"
              variant="outline"
              className="gap-2"
              onClick={handleDownloadAgain}
            >
              <FileDown size={16} />
              Download Again
            </Button>
          </CardFooter>
        </Card>
      )}

      <div className="text-center text-sm text-gray-500 mb-8">
        <p>
          This report is saved locally on your device and is not stored on our servers for your privacy.
        </p>
      </div>
    </div>
  );
}
