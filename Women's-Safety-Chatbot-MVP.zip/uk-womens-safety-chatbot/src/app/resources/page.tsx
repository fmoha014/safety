"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ukWomenResources, getAllCategories, getResourcesByCategory, Resource } from "@/lib/data/resources";
import { Button } from "@/components/ui/button";
import { Phone, Globe, Clock, ArrowRight, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function ResourcesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const categories = getAllCategories();

  const filteredResources = activeCategory
    ? getResourcesByCategory(activeCategory as Resource["category"])
    : ukWomenResources;

  const searchedResources = searchQuery
    ? filteredResources.filter(
        resource =>
          resource.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          resource.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : filteredResources;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-4">UK Women&apos;s Safety Resources</h1>
        <p className="text-gray-600 max-w-3xl">
          Find resources, helplines, and support services across the United Kingdom for women experiencing violence, abuse, or harassment.
        </p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          <Input
            placeholder="Search resources..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={activeCategory === null ? "default" : "outline"}
            onClick={() => setActiveCategory(null)}
          >
            All
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "default" : "outline"}
              onClick={() => setActiveCategory(category)}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {/* Resources Grid */}
      {searchedResources.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {searchedResources.map((resource) => (
            <ResourceCard key={resource.id} resource={resource} />
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-500">No resources found matching your search criteria.</p>
          <Button
            variant="link"
            onClick={() => {
              setSearchQuery("");
              setActiveCategory(null);
            }}
          >
            Clear filters
          </Button>
        </div>
      )}

      {/* Help Text */}
      <div className="bg-violet-100 p-6 rounded-lg">
        <h2 className="text-xl font-bold mb-2">Need Immediate Help?</h2>
        <p>
          If you or someone you know is in immediate danger, please call <strong>999</strong>.
          If you cannot speak, press 55 when prompted on a mobile phone to be transferred to the police.
        </p>
      </div>
    </div>
  );
}

function ResourceCard({ resource }: { resource: Resource }) {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{resource.name}</CardTitle>
          <span className="text-xs font-medium px-2 py-1 rounded-full bg-violet-100 text-violet-800">
            {resource.category.charAt(0).toUpperCase() + resource.category.slice(1)}
          </span>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <CardDescription className="text-gray-600 mb-4">
          {resource.description}
        </CardDescription>
        <div className="space-y-3 text-sm">
          {resource.phoneNumber && (
            <div className="flex items-start gap-2">
              <Phone size={16} className="text-violet-500 mt-1 flex-shrink-0" />
              <span>{resource.phoneNumber}</span>
            </div>
          )}
          {resource.website && (
            <div className="flex items-start gap-2">
              <Globe size={16} className="text-violet-500 mt-1 flex-shrink-0" />
              <span className="break-all">{resource.website}</span>
            </div>
          )}
          {resource.hours && (
            <div className="flex items-start gap-2">
              <Clock size={16} className="text-violet-500 mt-1 flex-shrink-0" />
              <span>{resource.hours}</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-2">
        {resource.website && (
          <Button asChild variant="ghost" className="w-full">
            <a
              href={resource.website}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2"
            >
              Visit Website <ArrowRight size={16} />
            </a>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
