"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Bot, Sparkles, Save, RotateCcw } from "lucide-react";

export default function SettingsPage() {
  const [apiKey, setApiKey] = useState<string>("");
  const [enableGpt4, setEnableGpt4] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Load settings from localStorage on component mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Check localStorage for saved settings
      const savedApiKey = localStorage.getItem('openai_api_key') || '';
      const savedEnableGpt4 = localStorage.getItem('enable_gpt4') === 'true';

      setApiKey(savedApiKey);
      setEnableGpt4(savedEnableGpt4);
    }
  }, []);

  const saveSettings = () => {
    setIsLoading(true);

    try {
      // Save settings to localStorage
      localStorage.setItem('openai_api_key', apiKey);
      localStorage.setItem('enable_gpt4', enableGpt4.toString());

      toast.success("Settings saved successfully. Please refresh the page for changes to take effect.");
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error("Failed to save settings");
    } finally {
      setIsLoading(false);
    }
  };

  const resetSettings = () => {
    setApiKey("");
    setEnableGpt4(false);
    localStorage.removeItem('openai_api_key');
    localStorage.removeItem('enable_gpt4');

    toast.success("Settings reset to defaults. Please refresh the page for changes to take effect.");
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-gray-600 mt-2">
          Configure your chatbot and other application settings.
        </p>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Chatbot Configuration</CardTitle>
          <CardDescription>
            Settings related to the chat functionality
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <Label htmlFor="enable-gpt4" className="text-base font-medium">AI Mode</Label>
                <p className="text-sm text-gray-500 mt-1">
                  Choose between standard mode or enhanced AI capabilities
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={!enableGpt4 ? "default" : "outline"}
                  size="sm"
                  className="flex items-center gap-1"
                  onClick={() => setEnableGpt4(false)}
                >
                  <Bot size={16} />
                  Standard
                </Button>
                <Button
                  type="button"
                  variant={enableGpt4 ? "default" : "outline"}
                  size="sm"
                  className="flex items-center gap-1"
                  onClick={() => setEnableGpt4(true)}
                >
                  <Sparkles size={16} />
                  GPT-4 Enhanced
                </Button>
              </div>
            </div>

            {enableGpt4 && (
              <div className="space-y-2 p-4 bg-violet-50 rounded-md border border-violet-200">
                <Label htmlFor="api-key" className="text-base font-medium">OpenAI API Key</Label>
                <Input
                  id="api-key"
                  type="password"
                  placeholder="Enter your OpenAI API key"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Your API key is stored locally in your browser and is never sent to our servers.
                </p>
              </div>
            )}
          </div>

          <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200">
            <h3 className="text-sm font-medium text-yellow-800">About AI Mode</h3>
            <p className="text-sm text-yellow-700 mt-1">
              Enhanced AI mode uses OpenAI's GPT-4 model to provide more advanced help.
              This requires your own API key and may incur costs based on OpenAI's pricing.
              All processing happens directly between your browser and OpenAI.
            </p>
          </div>

          <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
            <h3 className="text-sm font-medium text-blue-800">Note</h3>
            <p className="text-sm text-blue-700 mt-1">
              After saving your settings, please refresh the chat page for the changes to take effect.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={resetSettings}
            className="flex items-center gap-1"
          >
            <RotateCcw size={16} />
            Reset to Default
          </Button>
          <Button
            type="button"
            onClick={saveSettings}
            disabled={isLoading || (enableGpt4 && !apiKey)}
            className="flex items-center gap-1"
          >
            <Save size={16} />
            Save Settings
          </Button>
        </CardFooter>
      </Card>

      <div className="text-center text-sm text-gray-500">
        <p>
          These settings are saved in your browser. Clearing your browser data will reset these settings.
        </p>
      </div>
    </div>
  );
}
