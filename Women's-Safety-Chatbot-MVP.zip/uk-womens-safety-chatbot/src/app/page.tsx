import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { SafetyBar } from "@/components/safety/safety-bar";

export default function Home() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="py-12 px-4 text-center bg-violet-100 rounded-lg">
        <div className="max-w-3xl mx-auto space-y-6">
          <h1 className="text-4xl font-bold text-violet-900">SafeSpace UK</h1>
          <p className="text-xl text-gray-700">
            Supporting women across the United Kingdom with resources, chat support, and incident reporting tools.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mt-8">
            <Button asChild size="lg" className="bg-violet-700 hover:bg-violet-800">
              <Link href="/chat">Chat with Support Bot</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/resources">Find Resources</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Quick Exit Reminder */}
      <SafetyBar />

      {/* Features Section */}
      <section>
        <h2 className="text-2xl font-bold text-center mb-8">How We Can Help</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>UK Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Access a comprehensive directory of support services, hotlines, shelters, and legal resources across the UK.</p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="ghost" className="w-full">
                <Link href="/resources">Find Resources</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Support Chat</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Chat with our supportive bot for immediate guidance, information, and emotional support in a safe space.</p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="ghost" className="w-full">
                <Link href="/chat">Start Chat</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Incident Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <p>Create detailed incident reports with the option to upload evidence and download documentation for your records.</p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="ghost" className="w-full">
                <Link href="/report">Report Incident</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </section>

      {/* Emergency Resources */}
      <section className="bg-violet-900 text-white p-6 rounded-lg">
        <h2 className="text-2xl font-bold mb-4">Emergency Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-violet-800 rounded-md">
            <h3 className="text-xl font-semibold mb-2">In Immediate Danger</h3>
            <p className="text-lg mb-2">Call 999 (or 112)</p>
            <p className="text-sm">If you can't speak, press 55 when prompted on a mobile phone.</p>
          </div>
          <div className="p-4 bg-violet-800 rounded-md">
            <h3 className="text-xl font-semibold mb-2">National Domestic Abuse Helpline</h3>
            <p className="text-lg mb-2">0808 2000 247</p>
            <p className="text-sm">Free, confidential, 24/7 support</p>
          </div>
        </div>
      </section>
    </div>
  );
}
