"use client";

import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar } from "@/components/ui/avatar";
import { Message as MessageType } from "@/lib/utils/chat-helpers";
import { getChatbotResponse } from "@/lib/utils/ai-helpers";
import { v4 as uuidv4 } from "uuid";
import { SendIcon, RefreshCw, Bot, Sparkles, Settings } from "lucide-react";
import { toast } from "sonner";
import Link from "next/link";
import { SafetyBar } from "@/components/safety/safety-bar";

export default function ChatPage() {
  // State for AI settings
  const [isGpt4Enabled, setIsGpt4Enabled] = useState<boolean>(
    process.env.NEXT_PUBLIC_ENABLE_GPT4 === 'true'
  );

  const [messages, setMessages] = useState<MessageType[]>([
    {
      id: uuidv4(),
      role: "assistant",
      content: "Hello, I'm here to help with women's safety resources in the UK. How can I assist you today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load GPT-4 settings from localStorage on component mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const storedGpt4Setting = localStorage.getItem('enable_gpt4');
      if (storedGpt4Setting !== null) {
        setIsGpt4Enabled(storedGpt4Setting === 'true');
      }
    }
  }, []);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: MessageType = {
      id: uuidv4(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);

    try {
      // Format chat history for the AI
      const chatHistory = messages.map(msg => ({
        role: msg.role as 'user' | 'assistant' | 'system',
        content: msg.content
      }));

      // Process with AI
      const responseContent = await getChatbotResponse(userMessage.content, chatHistory);

      const assistantMessage: MessageType = {
        id: uuidv4(),
        role: "assistant",
        content: responseContent,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error processing message:", error);
      toast.error("Sorry, I encountered an issue processing your message. Please try again.");

      // Add fallback message
      const errorMessage: MessageType = {
        id: uuidv4(),
        role: "assistant",
        content: "I'm having trouble connecting to my knowledge base. If you need immediate help, please call 999 or the National Domestic Abuse Helpline at 0808 2000 247.",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const resetChat = () => {
    setMessages([
      {
        id: uuidv4(),
        role: "assistant",
        content: "Hello, I'm here to help with women's safety resources in the UK. How can I assist you today?",
        timestamp: new Date(),
      },
    ]);
    toast.success("Chat has been reset");
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Chat Support</h1>
        <p className="text-gray-600 mt-2">
          Chat with our {isGpt4Enabled ? 'AI-powered' : ''} support bot for guidance, resources, and assistance. All conversations are private and not stored on our servers.
        </p>
      </div>

      {/* Safety Bar */}
      <SafetyBar />

      {/* GPT-4 Disclaimer - only shown if enabled */}
      {isGpt4Enabled && (
        <div className="bg-violet-100 p-4 rounded-md mb-6">
          <p className="text-violet-800 text-sm flex items-center gap-2">
            <Sparkles size={16} className="text-violet-500" />
            <strong>Enhanced Support:</strong> Our chat is powered by advanced AI to provide better assistance. No personal information is sent to external servers without your consent.
          </p>
        </div>
      )}

      {/* AI Settings Shortcut */}
      <div className="flex justify-end mb-4">
        <Link href="/settings">
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Settings size={14} />
            Configure AI Settings
          </Button>
        </Link>
      </div>

      <Card className="h-[70vh] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 py-4">
          <div className="flex items-center gap-2">
            <CardTitle>SafeSpace UK Support</CardTitle>
            {isGpt4Enabled ? (
              <span className="bg-violet-100 text-violet-800 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                <Sparkles size={12} />
                GPT-4 Powered
              </span>
            ) : (
              <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                <Bot size={12} />
                Standard
              </span>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={resetChat}
            className="h-8 gap-1 text-gray-500"
          >
            <RefreshCw size={14} />
            <span>Reset</span>
          </Button>
        </CardHeader>

        <CardContent className="overflow-y-auto flex-grow p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                  <Avatar className={`w-8 h-8 ${message.role === "assistant" ? "bg-violet-600" : "bg-gray-200"}`}>
                    <span className="text-xs">
                      {message.role === "user" ? "You" : isGpt4Enabled ? "AI" : "Bot"}
                    </span>
                  </Avatar>
                  <div
                    className={`p-3 rounded-lg ${
                      message.role === "user"
                        ? "bg-violet-600 text-white"
                        : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    <div className="whitespace-pre-line">{message.content}</div>
                    <div
                      className={`text-xs mt-1 ${
                        message.role === "user" ? "text-violet-200" : "text-gray-500"
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="flex gap-3 max-w-[80%]">
                  <Avatar className="w-8 h-8 bg-violet-600">
                    <span className="text-xs">{isGpt4Enabled ? "AI" : "Bot"}</span>
                  </Avatar>
                  <div className="p-3 rounded-lg bg-gray-100 text-gray-800">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0s" }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </CardContent>

        <CardFooter className="p-4 border-t">
          <div className="flex w-full gap-2">
            <Textarea
              placeholder="Type your message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="flex-1 min-h-10 resize-none"
              rows={2}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim() || isTyping}
              className="h-full"
            >
              <SendIcon className="h-4 w-4" />
              <span className="sr-only">Send message</span>
            </Button>
          </div>
        </CardFooter>
      </Card>

      <div className="mt-6 text-center text-sm text-gray-500">
        <p>
          For immediate help, call the National Domestic Abuse Helpline: <strong>0808 2000 247</strong>
        </p>
        <p className="mt-1">
          In an emergency, always call <strong>999</strong>
        </p>
      </div>
    </div>
  );
}
