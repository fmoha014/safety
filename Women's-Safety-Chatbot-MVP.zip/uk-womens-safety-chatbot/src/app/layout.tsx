import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { PageHeader } from "@/components/layout/page-header";
import { PageFooter } from "@/components/layout/page-footer";
import { Toaster } from "sonner";
import { QuickExitProvider } from "@/components/safety/quick-exit-provider";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "SafeSpace UK - Women's Safety Resources",
  description: "Access support resources, chat with a supportive bot, and create detailed incident reports for women's safety in the UK.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full">
      <body className={`${inter.className} min-h-screen flex flex-col`}>
        <QuickExitProvider>
          <div className="flex-grow">
            <PageHeader />
            <main className="container mx-auto px-4 py-6">
              {/* We don't include SafetyBar here because each page will decide whether to include it */}
              {children}
            </main>
          </div>
          <Toaster position="top-right" />
          <PageFooter />
        </QuickExitProvider>
      </body>
    </html>
  );
}
