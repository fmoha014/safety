"use client";

import Link from "next/link";
import { useQuickExit } from "../safety/quick-exit-provider";

export function PageFooter() {
  const { triggerQuickExit } = useQuickExit();

  return (
    <footer className="bg-violet-900 text-white mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">SafeSpace UK</h3>
            <p className="text-sm text-violet-200">
              Providing support and resources for women experiencing violence and abuse in the United Kingdom.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="hover:text-violet-200 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/resources" className="hover:text-violet-200 transition-colors">
                  Resources
                </Link>
              </li>
              <li>
                <Link href="/chat" className="hover:text-violet-200 transition-colors">
                  Chat Support
                </Link>
              </li>
              <li>
                <Link href="/report" className="hover:text-violet-200 transition-colors">
                  Incident Report
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Emergency Contact</h3>
            <p className="text-sm">
              <strong>In an emergency:</strong> Call 999
            </p>
            <p className="text-sm mt-2">
              <strong>National Domestic Abuse Helpline:</strong><br />
              0808 2000 247 (24/7)
            </p>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-violet-800 text-sm text-center text-violet-300">
          <p>
            SafeSpace UK - This is a secure website. Your browsing history can be cleared for safety.
          </p>
          <div className="mt-2">
            <button
              onClick={triggerQuickExit}
              className="text-violet-200 underline hover:text-white transition-colors"
              aria-label="Quick exit - Press ESC key to exit quickly"
            >
              Quick Exit (ESC)
            </button>
          </div>
          <p className="mt-4">
            &copy; {new Date().getFullYear()} SafeSpace UK - All rights reserved
          </p>
        </div>
      </div>
    </footer>
  );
}
