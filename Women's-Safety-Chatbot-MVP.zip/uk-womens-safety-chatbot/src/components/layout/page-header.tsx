"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { MenuIcon, Settings, LogOut } from "lucide-react";
import { useState } from "react";
import { useQuickExit } from "../safety/quick-exit-provider";

const navigationItems = [
  { label: "Home", href: "/" },
  { label: "Resources", href: "/resources" },
  { label: "Chat", href: "/chat" },
  { label: "Report", href: "/report" },
  { label: "Emergency", href: "/emergency" },
];

export function PageHeader() {
  const [isOpen, setIsOpen] = useState(false);
  const { triggerQuickExit } = useQuickExit();

  return (
    <header className="bg-violet-900 text-white py-4 sticky top-0 z-10">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold flex items-center gap-2">
          SafeSpace UK
        </Link>

        {/* Desktop navigation */}
        <div className="hidden md:flex items-center">
          <nav className="flex gap-6 mr-4">
            {navigationItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="hover:text-violet-200 transition-colors"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Desktop Quick Exit Button */}
          <div className="flex items-center gap-2">
            <Link href="/settings">
              <Button variant="ghost" size="icon" className="text-white hover:text-violet-200">
                <Settings className="h-5 w-5" />
                <span className="sr-only">Settings</span>
              </Button>
            </Link>

            <Button
              variant="ghost"
              size="sm"
              onClick={triggerQuickExit}
              className="bg-red-600 hover:bg-red-700 text-white rounded-md flex items-center gap-1 px-3"
            >
              <LogOut className="h-4 w-4" />
              <span>Quick Exit</span>
            </Button>
          </div>
        </div>

        {/* Mobile navigation */}
        <div className="flex items-center gap-2 md:hidden">
          {/* Mobile Quick Exit Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={triggerQuickExit}
            className="bg-red-600 hover:bg-red-700 text-white rounded-md"
          >
            <LogOut className="h-4 w-4 mr-1" />
            <span>Exit</span>
          </Button>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="text-white">
                <MenuIcon className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-violet-900 text-white">
              <nav className="flex flex-col gap-4 mt-8">
                {navigationItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="text-lg hover:text-violet-200 transition-colors"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
                <Link
                  href="/settings"
                  className="text-lg hover:text-violet-200 transition-colors flex items-center gap-2"
                  onClick={() => setIsOpen(false)}
                >
                  <Settings size={18} />
                  Settings
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
