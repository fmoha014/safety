"use client";

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import GoogleSearchSite from './google-search-site';

// Create context for quick exit functionality
type QuickExitContextType = {
  triggerQuickExit: () => void;
  resetQuickExit: () => void;
  isQuickExitActive: boolean;
};

const QuickExitContext = createContext<QuickExitContextType>({
  triggerQuickExit: () => {},
  resetQuickExit: () => {},
  isQuickExitActive: false
});

export const useQuickExit = () => {
  const context = useContext(QuickExitContext);
  return context;
};

export const QuickExitProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isQuickExitActive, setIsQuickExitActive] = useState(false);
  const [isBrowser, setIsBrowser] = useState(false);

  // Initialize browser detection after mount
  useEffect(() => {
    setIsBrowser(true);
  }, []);

  // Use useCallback to memoize these functions
  const triggerQuickExit = useCallback(() => {
    if (!isBrowser) return;

    // Change page title to something innocuous
    document.title = "Google";

    // Set quick exit state to true
    setIsQuickExitActive(true);

    // Change the URL without navigating (for browser history)
    window.history.pushState({}, "Google", "/search");

    // Change favicon to Google favicon
    const favicon = document.querySelector("link[rel='icon']");
    if (favicon) {
      (favicon as HTMLLinkElement).href = "/google-favicon.ico";
    }
  }, [isBrowser]);

  const resetQuickExit = useCallback(() => {
    if (!isBrowser) return;

    // Restore original title
    document.title = "SafeSpace UK - Women's Safety Resources";

    // Set quick exit state to false
    setIsQuickExitActive(false);

    // Restore original URL without navigating
    window.history.pushState({}, "SafeSpace UK", "/");

    // Restore original favicon
    const favicon = document.querySelector("link[rel='icon']");
    if (favicon) {
      (favicon as HTMLLinkElement).href = "/favicon.ico";
    }
  }, [isBrowser]);

  // Listen for the escape key press
  useEffect(() => {
    if (!isBrowser) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        triggerQuickExit();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isBrowser, triggerQuickExit]);

  // Create an additional useEffect to handle browser back button
  useEffect(() => {
    if (!isBrowser) return;

    const handlePopState = () => {
      if (isQuickExitActive) {
        // Prevent going back to the SafeSpace site if someone clicks back
        window.history.pushState({}, "Google", "/search");
      }
    };

    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [isBrowser, isQuickExitActive]);

  return (
    <QuickExitContext.Provider value={{ triggerQuickExit, resetQuickExit, isQuickExitActive }}>
      {isQuickExitActive && isBrowser ? <GoogleSearchSite /> : children}
    </QuickExitContext.Provider>
  );
};

export default QuickExitProvider;
