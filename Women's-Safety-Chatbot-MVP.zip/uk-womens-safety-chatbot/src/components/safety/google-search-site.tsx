"use client";

import React, { useState, useEffect } from 'react';
import { Search, Mic, Image as ImageIcon, Grid, ArrowLeft } from 'lucide-react';
import { useQuickExit } from './quick-exit-provider';

export const GoogleSearchSite: React.FC = () => {
  const { resetQuickExit } = useQuickExit();
  const [searchQuery, setSearchQuery] = useState("");
  const [showReturnButton, setShowReturnButton] = useState(false);

  // Add keyboard shortcut listener for Alt+S
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Listen for Alt+S (or Option+S on Mac)
      if (event.altKey && event.key.toLowerCase() === 's') {
        resetQuickExit();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [resetQuickExit]);

  // Handle form submission (prevent default and do nothing)
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Do nothing - this is just for show
  };

  // Handle input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);

    // Easter egg: If someone types "safespace" or "safe space", show the return button
    if (e.target.value.toLowerCase().includes('safespace') ||
        e.target.value.toLowerCase().includes('safe space')) {
      setShowReturnButton(true);
    } else if (showReturnButton && !e.target.value.toLowerCase().includes('safe')) {
      setShowReturnButton(false);
    }
  };

  // Create random suggestions based on the query
  const getRandomSuggestions = () => {
    const commonSuggestions = [
      "restaurants near me",
      "weather forecast",
      "news today",
      "movie showtimes",
      "recipes for dinner",
      "best coffee shops",
      "shopping online",
      "latest tech news",
      "travel destinations",
      "local events"
    ];

    if (!searchQuery) return null;

    const matchingSuggestions = commonSuggestions
      .filter(suggestion => suggestion.includes(searchQuery.toLowerCase()) || Math.random() > 0.7)
      .slice(0, 5);

    // Add a special return suggestion if typing "safe"
    if (searchQuery.toLowerCase().includes('safe') && !matchingSuggestions.some(s => s.includes('safe'))) {
      matchingSuggestions.unshift("safespace uk women's resources");
    }

    return (
      <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-lg mt-1 shadow-lg z-10">
        {matchingSuggestions.map((suggestion, index) => (
          <div
            key={index}
            className="px-4 py-2 hover:bg-gray-100 cursor-pointer flex items-center"
            onClick={() => {
              if (suggestion.includes("safespace")) {
                setShowReturnButton(true);
                setSearchQuery("safespace uk women's resources");
              }
            }}
          >
            <Search size={16} className="text-gray-400 mr-3" />
            <span>{suggestion}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="bg-white min-h-screen flex flex-col">
      {/* Header */}
      <header className="flex justify-end items-center p-4 text-sm">
        <div className="flex items-center space-x-4">
          <a className="text-gray-600 hover:underline">Gmail</a>
          <a className="text-gray-600 hover:underline">Images</a>
          <button className="p-2 hover:bg-gray-100 rounded-full">
            <Grid size={20} className="text-gray-600" />
          </button>
          <button className="bg-blue-500 text-white px-4 py-2 rounded-md text-sm">
            Sign in
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow flex flex-col items-center justify-center px-6 -mt-20">
        <div className="w-full max-w-2xl">
          {/* Google Logo */}
          <div className="text-center mb-6">
            <div className="text-6xl font-sans mb-6 tracking-tighter">
              <span className="text-blue-500">G</span>
              <span className="text-red-500">o</span>
              <span className="text-yellow-500">o</span>
              <span className="text-blue-500">g</span>
              <span className="text-green-500">l</span>
              <span className="text-red-500">e</span>
            </div>
          </div>

          {/* Search Box */}
          <form onSubmit={handleSearch} className="relative mb-8">
            <div className="flex items-center w-full border border-gray-200 rounded-full px-5 py-3 hover:shadow-md focus-within:shadow-md">
              <Search size={20} className="text-gray-400 mr-3" />
              <input
                type="text"
                className="flex-grow outline-none text-black bg-transparent"
                autoFocus
                value={searchQuery}
                onChange={handleInputChange}
                aria-label="Search Google"
                placeholder={showReturnButton ? "Press Alt+S to return to SafeSpace" : "Search Google or type a URL"}
              />
              <button type="button" className="ml-2">
                <Mic size={20} className="text-blue-500" aria-label="Search by voice" />
              </button>
              <button type="button" className="ml-2">
                <ImageIcon size={20} className="text-blue-500" aria-label="Search by image" />
              </button>
            </div>

            {/* Search suggestions dropdown */}
            {searchQuery.length > 0 && getRandomSuggestions()}
          </form>

          {/* Buttons */}
          <div className="flex justify-center space-x-2 mb-8">
            <button
              className="bg-gray-100 hover:bg-gray-200 text-sm px-4 py-2 rounded"
              onClick={handleSearch}
            >
              Google Search
            </button>
            <button
              className="bg-gray-100 hover:bg-gray-200 text-sm px-4 py-2 rounded"
              onClick={handleSearch}
            >
              I'm Feeling Lucky
            </button>
          </div>

          {/* Return button (only visible after typing "safespace") */}
          {showReturnButton && (
            <div className="text-center mt-4 mb-4">
              <button
                onClick={resetQuickExit}
                className="bg-violet-600 text-white text-sm px-4 py-2 rounded flex items-center mx-auto"
              >
                <ArrowLeft size={16} className="mr-2" />
                Return to SafeSpace UK
              </button>
              <p className="text-xs text-gray-500 mt-1">Or press Alt+S to return</p>
            </div>
          )}

          {/* Languages */}
          <div className="text-center text-sm text-gray-700">
            <p>
              Google offered in:
              <a href="#" className="text-blue-700 hover:underline ml-1">English</a>
              <a href="#" className="text-blue-700 hover:underline ml-1">Français</a>
              <a href="#" className="text-blue-700 hover:underline ml-1">Español</a>
              <a href="#" className="text-blue-700 hover:underline ml-1">Deutsch</a>
              <a href="#" className="text-blue-700 hover:underline ml-1">Italiano</a>
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 text-gray-500 text-sm mt-auto">
        <div className="px-6 py-3 border-b border-gray-300">
          <p>United Kingdom</p>
        </div>
        <div className="px-6 py-3 flex flex-col md:flex-row md:justify-between">
          <div className="flex flex-wrap mb-3 md:mb-0 space-x-6">
            <a className="hover:underline mb-2 md:mb-0">About</a>
            <a className="hover:underline mb-2 md:mb-0">Advertising</a>
            <a className="hover:underline mb-2 md:mb-0">Business</a>
            <a className="hover:underline mb-2 md:mb-0">How Search works</a>
          </div>
          <div className="flex flex-wrap space-x-6">
            <a className="hover:underline mb-2 md:mb-0">Privacy</a>
            <a className="hover:underline mb-2 md:mb-0">Terms</a>
            <a className="hover:underline mb-2 md:mb-0">Settings</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default GoogleSearchSite;
