"use client";

import { useQuickExit } from "./quick-exit-provider";
import { LogOut } from "lucide-react";

export function SafetyBar() {
  const { triggerQuickExit } = useQuickExit();

  return (
    <div className="bg-yellow-100 text-yellow-800 p-3 rounded-md text-center mb-6 flex items-center justify-center">
      <span className="font-medium mr-2">Safety First:</span>
      <span className="mr-4">Press ESC key or click "Quick Exit" to instantly switch to a Google search page.</span>
      <button
        onClick={triggerQuickExit}
        className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded flex items-center text-sm"
      >
        <LogOut size={14} className="mr-1" />
        Quick Exit
      </button>
    </div>
  );
}
