"use client";

import React from 'react';
import Image from 'next/image';

export const FakeNewsSite: React.FC = () => {
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const newsStories = [
    {
      title: "UK economy shows stronger than expected growth",
      category: "Business",
      image: "https://ext.same-assets.com/0/1065795366.webp",
      summary: "The UK economy grew by 0.6% in the last quarter, higher than the 0.4% predicted by economists."
    },
    {
      title: "New climate agreement reached at international summit",
      category: "Climate",
      image: "https://ext.same-assets.com/0/1065795366.webp",
      summary: "World leaders have agreed to new carbon reduction targets aimed at limiting global warming."
    },
    {
      title: "Tech innovations showcased at annual conference",
      category: "Technology",
      image: "https://ext.same-assets.com/0/1065795366.webp",
      summary: "The latest advancements in AI and renewable energy took center stage at this year's tech conference."
    },
    {
      title: "National sports team advances to semi-finals",
      category: "Sport",
      image: "https://ext.same-assets.com/0/1065795366.webp",
      summary: "In a thrilling match that went to extra time, the national team secured their place in the tournament semi-finals."
    },
    {
      title: "Cultural festival celebrates diversity across the UK",
      category: "Culture",
      image: "https://ext.same-assets.com/0/1065795366.webp",
      summary: "The annual festival brought together performances and exhibitions from communities across the nation."
    }
  ];

  return (
    <div className="bg-white min-h-screen">
      {/* Header */}
      <header className="bg-black text-white">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <div className="font-bold text-2xl mr-8">
                NEWS
              </div>
              <nav className="hidden md:flex space-x-6 text-sm">
                <a className="hover:text-gray-300">Home</a>
                <a className="hover:text-gray-300">UK</a>
                <a className="hover:text-gray-300">World</a>
                <a className="hover:text-gray-300">Business</a>
                <a className="hover:text-gray-300">Politics</a>
                <a className="hover:text-gray-300">Tech</a>
                <a className="hover:text-gray-300">Science</a>
                <a className="hover:text-gray-300">Health</a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="hidden md:block">
                <input type="text" placeholder="Search" className="px-3 py-1 bg-gray-800 text-white rounded text-sm" />
              </div>
              <div>Sign in</div>
            </div>
          </div>
        </div>
      </header>

      {/* Welcome Bar */}
      <div className="bg-gray-100 py-2 border-b border-gray-300">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <div className="text-sm">{formattedDate}</div>
            <div className="text-sm">Welcome to NEWS</div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {/* Top Story */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-4">Top Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gray-100 p-4 rounded-md">
              <h3 className="text-xl font-bold mb-2">Prime Minister announces new infrastructure investment</h3>
              <div className="h-48 bg-gray-300 mb-3 relative overflow-hidden">
                <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-1 text-xs">BREAKING</div>
              </div>
              <p className="text-gray-700">
                The Prime Minister has unveiled a £5 billion infrastructure plan aimed at improving transportation and digital connectivity across the nation, with a focus on previously underserved regions.
              </p>
            </div>
            <div className="space-y-4">
              {newsStories.slice(0, 3).map((story, index) => (
                <div key={index} className="flex gap-4 pb-3 border-b border-gray-200">
                  <div className="w-24 h-24 bg-gray-300 flex-shrink-0"></div>
                  <div>
                    <span className="text-red-600 text-sm font-semibold">{story.category}</span>
                    <h4 className="font-bold">{story.title}</h4>
                    <p className="text-sm text-gray-600">{story.summary}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {newsStories.map((story, index) => (
            <div key={index} className="border border-gray-200 rounded-md overflow-hidden">
              <div className="h-40 bg-gray-300"></div>
              <div className="p-4">
                <span className="text-red-600 text-sm font-semibold">{story.category}</span>
                <h3 className="font-bold mb-2">{story.title}</h3>
                <p className="text-sm text-gray-600">{story.summary}</p>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white mt-10 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <h4 className="font-bold mb-4">News</h4>
              <ul className="space-y-2 text-sm">
                <li>Home</li>
                <li>UK</li>
                <li>World</li>
                <li>Business</li>
                <li>Politics</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Entertainment</h4>
              <ul className="space-y-2 text-sm">
                <li>Arts</li>
                <li>Music</li>
                <li>TV</li>
                <li>Film</li>
                <li>Gaming</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Sport</h4>
              <ul className="space-y-2 text-sm">
                <li>Football</li>
                <li>Cricket</li>
                <li>Rugby</li>
                <li>Tennis</li>
                <li>Golf</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">More</h4>
              <ul className="space-y-2 text-sm">
                <li>Weather</li>
                <li>Sounds</li>
                <li>Travel</li>
                <li>Terms of Use</li>
                <li>About Us</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t border-gray-700 text-sm text-gray-400 text-center">
            <p>© {new Date().getFullYear()} NEWS. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default FakeNewsSite;
