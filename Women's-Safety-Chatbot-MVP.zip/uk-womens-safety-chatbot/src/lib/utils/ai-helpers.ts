import OpenAI from 'openai';
import { ukWomenResources, Resource } from "@/lib/data/resources";
import { detectIntent, generateResponse } from './chat-helpers';

// This function gets settings from environment and localStorage
const getSettings = () => {
  // Default to environment variables first
  let apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY || '';
  let isEnabled = process.env.NEXT_PUBLIC_ENABLE_GPT4 === 'true';

  // Check if we're in a browser environment
  if (typeof window !== 'undefined') {
    // Override with localStorage values if available
    const storedApiKey = localStorage.getItem('openai_api_key');
    const storedEnabled = localStorage.getItem('enable_gpt4');

    if (storedApiKey) {
      apiKey = storedApiKey;
    }

    if (storedEnabled !== null) {
      isEnabled = storedEnabled === 'true';
    }
  }

  return { apiKey, isEnabled };
};

// Initialize OpenAI client dynamically
const createOpenAIClient = () => {
  const { apiKey, isEnabled } = getSettings();

  if (!isEnabled || !apiKey) {
    return null;
  }

  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true // For client-side use
  });
};

// System prompt to guide the model's behavior
const systemPrompt = `
You are a supportive and informative assistant for SafeSpace UK, a platform providing resources and support for women experiencing violence and abuse in the United Kingdom.

Your primary roles are:
1. Provide emotional support and validation to users who may be experiencing distress
2. Provide accurate information about UK-specific resources for women's safety
3. Guide users on how to document incidents and create reports
4. Help with safety planning in dangerous situations

Always prioritize user safety. If someone appears to be in immediate danger, direct them to call 999 (or press 55 if they cannot speak).

Here are the key UK resources you should be aware of:
${ukWomenResources.map(r => `- ${r.name}: ${r.description}${r.phoneNumber ? ` (${r.phoneNumber})` : ''}`).join('\n')}

Respond with compassion, but remain factual and clear. If you don't know something, acknowledge this and suggest where the user might find more information.

Do not ask for personally identifying information and remind users not to share sensitive personal details that could compromise their safety.
`;

// Function to get a response from the chatbot (GPT-4 or fallback)
export async function getChatbotResponse(
  userMessage: string,
  chatHistory: { role: 'user' | 'assistant' | 'system', content: string }[]
): Promise<string> {
  // Check settings
  const { isEnabled } = getSettings();

  // If GPT-4 is not enabled, use our basic intent detection
  if (!isEnabled) {
    console.log('Using fallback intent detection system');
    const intent = detectIntent(userMessage);
    return generateResponse(intent, userMessage);
  }

  // Create OpenAI client dynamically
  const openai = createOpenAIClient();

  // If client creation failed, fall back to intent detection
  if (!openai) {
    console.log('Failed to create OpenAI client, using fallback');
    const intent = detectIntent(userMessage);
    return generateResponse(intent, userMessage);
  }

  try {
    // Build the messages array with system prompt and chat history
    const messages = [
      { role: 'system' as const, content: systemPrompt },
      ...chatHistory,
      { role: 'user' as const, content: userMessage }
    ];

    // Call the OpenAI API
    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo', // Use GPT-4 for better understanding and responses
      messages,
      temperature: 0.7, // Balance between creativity and consistency
      max_tokens: 500 // Limit response length
    });

    // Extract and return the assistant's message
    return response.choices[0]?.message?.content ||
           "I'm sorry, I'm having trouble connecting to my knowledge base. If you need immediate help, please call 999 or the National Domestic Abuse Helpline at 0808 2000 247.";
  } catch (error) {
    console.error('Error getting chatbot response:', error);

    // Fallback to our basic intent detection system
    const intent = detectIntent(userMessage);
    return generateResponse(intent, userMessage);
  }
}

// Function to get relevant resources based on user query
export function getRelevantResources(query: string): Resource[] {
  // Convert query to lowercase for case-insensitive matching
  const lowerQuery = query.toLowerCase();

  // Score each resource based on relevance to the query
  const scoredResources = ukWomenResources.map(resource => {
    let score = 0;

    // Check name match
    if (resource.name.toLowerCase().includes(lowerQuery)) {
      score += 5;
    }

    // Check description match
    if (resource.description.toLowerCase().includes(lowerQuery)) {
      score += 3;
    }

    // Check category match
    if (resource.category.toLowerCase().includes(lowerQuery)) {
      score += 4;
    }

    // Additional scoring for specific keywords
    const keywords = [
      'emergency', 'immediate', 'crisis', 'danger', 'safety',
      'shelter', 'housing', 'accommodation',
      'legal', 'law', 'court', 'police',
      'counseling', 'therapy', 'support',
      'children', 'family'
    ];

    keywords.forEach(keyword => {
      if (lowerQuery.includes(keyword) &&
          (resource.name.toLowerCase().includes(keyword) ||
           resource.description.toLowerCase().includes(keyword))) {
        score += 2;
      }
    });

    return { resource, score };
  });

  // Sort by score (highest first) and take top results
  return scoredResources
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map(item => item.resource);
}
