import { ukWomenResources } from "@/lib/data/resources";

// Types for the chat system
export type MessageRole = "user" | "assistant" | "system";

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
}

// Intent types that our system can recognize
export type Intent =
  | "greeting"
  | "help"
  | "resources"
  | "emergency"
  | "report"
  | "specifics"
  | "safety"
  | "emotional_support"
  | "gratitude"
  | "goodbye"
  | "unknown";

// Function to detect the intent of a user message
export function detectIntent(message: string): Intent {
  const lowerMessage = message.toLowerCase();

  // Greeting patterns
  if (/^(hi|hello|hey|greetings|good (morning|afternoon|evening))/.test(lowerMessage)) {
    return "greeting";
  }

  // Help patterns
  if (/^(help|assistance|support|aid|how can|what can)/.test(lowerMessage) ||
      /can you help/.test(lowerMessage)) {
    return "help";
  }

  // Resource patterns
  if (/resources|services|organizations|charities|where can i (find|get)|hotline|helpline|numbers/.test(lowerMessage)) {
    return "resources";
  }

  // Emergency patterns
  if (/emergency|danger|urgent|immediate|threat|unsafe|scared|afraid|terrified/.test(lowerMessage)) {
    return "emergency";
  }

  // Report patterns
  if (/report|document|record|evidence|incident|file|police report/.test(lowerMessage)) {
    return "report";
  }

  // Questions about specific resources
  if (/shelter|legal|police|court|lawyer|solicitor|counseling|therapy|medical|health/.test(lowerMessage)) {
    return "specifics";
  }

  // Safety planning
  if (/safety plan|escape plan|leave safely|protect (myself|my children)|safety measures|secure/.test(lowerMessage)) {
    return "safety";
  }

  // Emotional support
  if (/feeling|scared|sad|depressed|anxious|worried|stress|trauma|hurt|pain/.test(lowerMessage)) {
    return "emotional_support";
  }

  // Gratitude
  if (/thank|thanks|appreciate|grateful/.test(lowerMessage)) {
    return "gratitude";
  }

  // Goodbye
  if (/bye|goodbye|see you|talk later/.test(lowerMessage)) {
    return "goodbye";
  }

  // Default unknown intent
  return "unknown";
}

// Function to get relevant resources based on message content
export function getRelevantResources(message: string) {
  const lowerMessage = message.toLowerCase();

  // Define keywords for different categories
  const categoryKeywords = {
    hotline: ["hotline", "call", "phone", "talk", "helpline", "speak"],
    support: ["support", "help", "assistance", "counseling", "therapy", "group"],
    shelter: ["shelter", "housing", "accommodation", "refuge", "place to stay", "safe house"],
    legal: ["legal", "lawyer", "solicitor", "court", "rights", "law", "police report", "justice"],
    safety: ["safety", "plan", "escape", "protection", "security", "safe"],
    health: ["health", "medical", "hospital", "doctor", "nurse", "injury", "treatment"]
  };

  // Check which categories have keywords in the message
  const matchedCategories = Object.entries(categoryKeywords)
    .filter(([_, keywords]) => keywords.some(keyword => lowerMessage.includes(keyword)))
    .map(([category]) => category as keyof typeof categoryKeywords);

  // If no categories matched, return an empty array
  if (matchedCategories.length === 0) {
    return [];
  }

  // Get resources that match any of the matched categories
  const relevantResources = ukWomenResources.filter(resource =>
    matchedCategories.includes(resource.category as keyof typeof categoryKeywords)
  );

  // Return up to 3 most relevant resources
  return relevantResources.slice(0, 3);
}

// Generate response based on intent
export function generateResponse(intent: Intent, message: string): string {
  switch (intent) {
    case "greeting":
      return "Hello, I'm here to help. I can provide resources for women's safety in the UK, help with creating incident reports, or offer guidance in emergency situations. How can I assist you today?";

    case "help":
      return "I'm here to support you. I can help with finding UK resources for women's safety, guide you through creating an incident report, or provide information on emergency services. What specific assistance do you need?";

    case "resources":
      const relevantResources = getRelevantResources(message);
      if (relevantResources.length > 0) {
        const resourceList = relevantResources.map(r => `- ${r.name}: ${r.description}${r.phoneNumber ? ` Call: ${r.phoneNumber}` : ''}`).join('\n');
        return `Here are some resources that might help:\n\n${resourceList}\n\nYou can view all available resources on our Resources page.`;
      } else {
        return "We have many UK resources for women experiencing abuse or violence. You can find hotlines, shelters, legal aid, and more on our Resources page. Would you like specific information about a particular type of resource?";
      }

    case "emergency":
      return "If you are in immediate danger, please call 999. If you cannot speak, press 55 when prompted on a mobile phone to be transferred to the police.\n\nThe National Domestic Abuse Helpline is available 24/7 at 0808 2000 247.\n\nYour safety is the priority. Do you need help finding local emergency services?";

    case "report":
      return "You can create a detailed incident report through our system. This can help document what happened, include evidence, and can be downloaded for your records or for sharing with authorities. Would you like to create a report now?";

    case "specifics":
      return "I can provide specific information about different types of resources available in the UK. This includes shelters, legal aid, counseling services, and more. What specific type of support are you looking for?";

    case "safety":
      return "Safety planning is important. This can include preparing essential documents, establishing a support network, and knowing safe exit routes. Would you like some guidance on creating a safety plan?";

    case "emotional_support":
      return "I understand this is a difficult time. Your feelings are valid, and it's important to know that what's happening is not your fault. Would it help to talk about how you're feeling, or would you prefer information about emotional support services?";

    case "gratitude":
      return "You're welcome. I'm here to help whenever you need support or information. Is there anything else I can assist you with today?";

    case "goodbye":
      return "Take care, and remember that support is available whenever you need it. You can return to this chat at any time.";

    case "unknown":
    default:
      return "I'm here to help with resources for women's safety in the UK. If you're looking for support services, help with reporting an incident, or emergency guidance, please let me know. How can I assist you today?";
  }
}
