import { jsPDF } from "jspdf";
import { saveAs } from "file-saver";

export interface IncidentReport {
  id: string;
  createdAt: Date;
  reportingPerson: {
    name: string;
    contactInfo: string;
  };
  incidentDetails: {
    date: string;
    time: string;
    location: string;
    description: string;
  };
  perpetratorDetails?: {
    name?: string;
    relationship?: string;
    description?: string;
  };
  witnessDetails?: {
    witnesses: boolean;
    names?: string;
    contactInfo?: string;
  };
  evidenceDetails?: {
    hasEvidence: boolean;
    descriptions?: string;
    fileNames?: string[];
  };
  impactStatement?: string;
  assistanceNeeded?: string;
  safetyMeasures?: string;
  optionalContent?: {
    policeReported?: boolean;
    policeReportNumber?: string;
    medicalAttention?: boolean;
    medicalFacility?: string;
  };
}

// Type for an object with string keys and various value types
type ReportSection = Record<string, string | boolean | string[] | number | undefined | null>;

export const generateReportPDF = (report: IncidentReport): void => {
  const doc = new jsPDF();

  // Title and metadata
  doc.setFontSize(22);
  doc.setTextColor(89, 65, 169); // Purple theme color
  doc.text("Incident Report", 105, 20, { align: "center" });

  doc.setFontSize(10);
  doc.setTextColor(100, 100, 100);
  doc.text(`Report ID: ${report.id}`, 105, 27, { align: "center" });
  doc.text(`Created: ${report.createdAt.toLocaleString()}`, 105, 32, { align: "center" });

  doc.setDrawColor(89, 65, 169);
  doc.line(20, 35, 190, 35);

  // Helper function for adding sections
  let yPosition = 42;
  const addSection = (title: string, content: ReportSection, excludeKeys: string[] = []) => {
    doc.setFontSize(14);
    doc.setTextColor(89, 65, 169);
    doc.text(title, 20, yPosition);
    yPosition += 6;

    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);

    Object.entries(content).forEach(([key, value]) => {
      // Skip keys that should be excluded
      if (excludeKeys.includes(key)) return;

      // Skip undefined, null, or empty values
      if (value === undefined || value === null || value === "") return;

      // Format key from camelCase to Title Case
      const formattedKey = key
        .replace(/([A-Z])/g, " $1")
        .replace(/^./, (str) => str.toUpperCase());

      // Handle boolean values
      let displayValue: string;
      if (typeof value === "boolean") {
        displayValue = value ? "Yes" : "No";
      } else if (Array.isArray(value)) {
        // Handle arrays (like fileNames)
        displayValue = value.join(", ");
      } else {
        // Convert to string for display
        displayValue = String(value);
      }

      // Check if we need to add a new page
      if (yPosition > 270) {
        doc.addPage();
        yPosition = 20;
      }

      doc.text(`${formattedKey}: ${displayValue}`, 25, yPosition);
      yPosition += 6;
    });

    yPosition += 5;
  };

  // Add sections
  addSection("Reporting Person", report.reportingPerson);
  addSection("Incident Details", report.incidentDetails);

  if (report.perpetratorDetails) {
    addSection("Perpetrator Details", report.perpetratorDetails);
  }

  if (report.witnessDetails) {
    addSection("Witness Information", report.witnessDetails);
  }

  if (report.evidenceDetails) {
    addSection("Evidence", report.evidenceDetails);
  }

  if (report.impactStatement) {
    if (yPosition > 240) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(14);
    doc.setTextColor(89, 65, 169);
    doc.text("Impact Statement", 20, yPosition);
    yPosition += 6;

    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);

    // Split long text into multiple lines
    const textLines = doc.splitTextToSize(report.impactStatement, 170);
    doc.text(textLines, 25, yPosition);
    yPosition += (textLines.length * 5) + 5;
  }

  if (report.assistanceNeeded) {
    if (yPosition > 240) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(14);
    doc.setTextColor(89, 65, 169);
    doc.text("Assistance Needed", 20, yPosition);
    yPosition += 6;

    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);

    const textLines = doc.splitTextToSize(report.assistanceNeeded, 170);
    doc.text(textLines, 25, yPosition);
    yPosition += (textLines.length * 5) + 5;
  }

  if (report.safetyMeasures) {
    if (yPosition > 240) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(14);
    doc.setTextColor(89, 65, 169);
    doc.text("Safety Measures", 20, yPosition);
    yPosition += 6;

    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);

    const textLines = doc.splitTextToSize(report.safetyMeasures, 170);
    doc.text(textLines, 25, yPosition);
    yPosition += (textLines.length * 5) + 5;
  }

  if (report.optionalContent) {
    addSection("Additional Information", report.optionalContent);
  }

  // Add footer
  const pageCount = doc.getNumberOfPages();
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.text(
      `Generated by SafeSpace UK | Page ${i} of ${pageCount}`,
      105,
      290,
      { align: "center" }
    );
    doc.text(
      "CONFIDENTIAL DOCUMENT",
      105,
      295,
      { align: "center" }
    );
  }

  // Save the PDF
  const fileName = `Incident_Report_${report.id.substring(0, 8)}.pdf`;
  doc.save(fileName);
};

export const saveEvidenceFile = async (file: File): Promise<string> => {
  try {
    // In a real app, you would upload this to secure storage
    // For this MVP, we'll create a local object URL
    const fileURL = URL.createObjectURL(file);
    return fileURL;
  } catch (error) {
    console.error("Error saving file:", error);
    throw new Error("Failed to save evidence file");
  }
};

export const createBlobFromURL = async (url: string): Promise<Blob> => {
  const response = await fetch(url);
  const blob = await response.blob();
  return blob;
};

export const downloadEvidenceFile = async (url: string, filename: string): Promise<void> => {
  try {
    const blob = await createBlobFromURL(url);
    saveAs(blob, filename);
  } catch (error) {
    console.error("Error downloading file:", error);
    throw new Error("Failed to download evidence file");
  }
};
