export type Resource = {
  id: string;
  name: string;
  description: string;
  phoneNumber?: string;
  website?: string;
  hours?: string;
  category: 'hotline' | 'support' | 'shelter' | 'legal' | 'safety' | 'health' | 'other';
};

export const ukWomenResources: Resource[] = [
  {
    id: 'national-domestic-abuse-helpline',
    name: 'National Domestic Abuse Helpline',
    description: 'Free, confidential helpline run by Refuge for women experiencing domestic abuse, their family, friends, and others calling on their behalf.',
    phoneNumber: '0808 2000 247',
    website: 'https://www.nationaldahelpline.org.uk/',
    hours: '24/7',
    category: 'hotline'
  },
  {
    id: 'womens-aid',
    name: 'Women\'s Aid',
    description: 'Women\'s Aid is a grassroots federation working together to provide life-saving services and build a future where domestic violence is not tolerated.',
    website: 'https://www.womensaid.org.uk/',
    hours: 'Varies by service',
    category: 'support'
  },
  {
    id: 'refuge',
    name: 'Refuge',
    description: 'The largest UK domestic abuse organization supporting thousands of women and children every day.',
    website: 'https://refuge.org.uk/',
    hours: 'Varies by service',
    category: 'shelter'
  },
  {
    id: 'live-fear-free',
    name: 'Live Fear Free (Wales)',
    description: 'Welsh Government funded helpline providing 24/7 support and advice to women experiencing domestic abuse.',
    phoneNumber: '0808 80 10 800',
    website: 'https://gov.wales/live-fear-free',
    hours: '24/7',
    category: 'hotline'
  },
  {
    id: 'scotland-domestic-abuse',
    name: 'Scotland\'s Domestic Abuse and Forced Marriage Helpline',
    description: 'Confidential service for anyone with experience of domestic abuse or forced marriage.',
    phoneNumber: '0800 027 1234',
    website: 'https://sdafmh.org.uk/',
    hours: '24/7',
    category: 'hotline'
  },
  {
    id: 'northern-ireland-domestic-abuse',
    name: 'Domestic & Sexual Abuse Helpline (Northern Ireland)',
    description: 'Managed by Nexus NI, offering free and confidential advice, support and referrals.',
    phoneNumber: '0808 802 1414',
    website: 'https://dsahelpline.org/',
    hours: '24/7',
    category: 'hotline'
  },
  {
    id: 'uk-police',
    name: 'UK Police',
    description: 'For emergencies, always call 999. If you can\'t speak, press 55 when prompted to be transferred to the police.',
    phoneNumber: '999 (emergency) or 101 (non-emergency)',
    hours: '24/7',
    category: 'safety'
  },
  {
    id: 'victim-support',
    name: 'Victim Support',
    description: 'Free and confidential support for victims of any crime, regardless of whether it was reported to the police.',
    phoneNumber: '08 08 16 89 111',
    website: 'https://www.victimsupport.org.uk/',
    hours: '24/7',
    category: 'support'
  },
  {
    id: 'rights-of-women',
    name: 'Rights of Women',
    description: 'Provides free legal advice to women on family law, criminal law, and immigration and asylum law.',
    website: 'https://rightsofwomen.org.uk/',
    hours: 'Varies by service',
    category: 'legal'
  },
  {
    id: 'nhs-domestic-abuse',
    name: 'NHS Domestic Abuse Support',
    description: 'Information on where to get help for domestic abuse and resources provided by the NHS.',
    website: 'https://www.nhs.uk/live-well/getting-help-for-domestic-violence/',
    category: 'health'
  },
  {
    id: 'bright-sky-app',
    name: 'Bright Sky App',
    description: 'A mobile app providing support and information to those experiencing domestic abuse or concerned about someone else.',
    website: 'https://www.hestia.org/brightsky',
    category: 'safety'
  },
  {
    id: 'safe-spaces',
    name: 'Safe Spaces',
    description: 'Safe, confidential rooms where victims can take time to reflect and access information on support services.',
    website: 'https://uksaysnomore.org/safespaces/',
    category: 'safety'
  }
];

export const getResourcesByCategory = (category: Resource['category']) => {
  return ukWomenResources.filter(resource => resource.category === category);
};

export const getAllCategories = (): Array<Resource['category']> => {
  const categories = new Set(ukWomenResources.map(resource => resource.category));
  return Array.from(categories);
};

export const getResourceById = (id: string): Resource | undefined => {
  return ukWomenResources.find(resource => resource.id === id);
};
